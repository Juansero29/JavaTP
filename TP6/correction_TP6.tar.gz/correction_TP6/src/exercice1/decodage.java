package exercice1;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Classe permettant de décoder le message du fichier.
 * Exercice1
 * @author carine
 *
 */
public class decodage {

	public static void main(String[] args) {
		String message = "Un fichier comme ça il y en a 17 tous les 59 voir tous les 44 . Et encore ... "
				+ "Etre spécifique est l'une de ses 40 principales particularités . On peut "
				+ "lui en trouver 56 autres . Dans les 49 caractères de son nom est concentré "
				+ "son objectif , et de son extension dépend la réussite de sa lecture . "
				+ "S'il est crypté soyez attentif à sa clé et à son 62 ème expéditeur , les 51 "
				+ "premiers ne comptent pas , sauf peut être le 49 ème ou le 50 ème . ";
	
		Scanner sc = new Scanner(message);
		int i;  //, cpt=0;
		ArrayList<Integer> listEntiers = new ArrayList<Integer>();
		ArrayList<String> listMots = new ArrayList<String>();
		String mot = null;
		while (sc.hasNext()) {
			if(sc.hasNextInt()){ 
        		i = sc.nextInt();
        	//	System.out.println("entier lu : "+i);
        		listEntiers.add(i);
        	}
			else{
				mot = sc.next();
        		listMots.add(mot);
        	//	System.out.println(cpt+ " : " +mot);
        	//	cpt++;
        	}
		 }   		
        sc.close();
        for(Integer j: listEntiers){
        	System.out.printf("%s ", listMots.get(j));
        }
        System.out.println("");

		
		
	}

}
