package exercice2;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

/**
 *  Classe Téléphone décrivant un téléphone ayant un comportement 
 *  assez proche d'un téléphone portable. Il a nottament une liste 
 *  de contacts permettant d'avoir des contacts enregistrés, ainsi 
 *  qu'une liste des numéros appelés.
 *  
 * @author casimon
 *
 */
public class Telephone {
	/** indique si le téléphone est décroché */
	private boolean decroche;
	/** indique si le téléphone est en communication */
	private boolean enCommunication;
	/** permet de retenir le numéro de téléphone composé par l'utilisateur */
	private String numeroCompose;
	/** liste des derniers numéros appelés */
	private LinkedList<String> listeDerniersNumAppeles;
	/** liste des contact enregistrés */
	private LinkedList<Contact> listeContacts;

	/**
	 * Constructeur d'un téléphone. À sa construction les listes de 
	 * 	contacts et de numéros appelés sont vides. 
	 */
	public Telephone(){
		decroche = false;
		enCommunication = false;
		numeroCompose = null;
		listeContacts = new LinkedList<Contact>();
		listeDerniersNumAppeles = new LinkedList<String>();
	}
	
	/**
	 * Permet de composer un numéro de téléphone. 
	 * @param numero Le numéro à composer.
	 */
	public void composer(String numero){
		if(! decroche ){
			numeroCompose = numero;
		}
	}
	/**
	 * Permet de décrocher le téléphone. Si il y a déjà un numéro de composé 
	 * alors le téléphone sera considéré décroché et en communication avec 
	 * le numéro composé. Si par contre il n'y a pas déjà de numéro composé 
	 * alors le numéro composé prendra la valeur du dernier numéro appelé et 
	 * le téléphone sera considéré comme décroché mais pas en communication 
	 * (il faudrait décroché à nouveau pour établir la communication). Si 
	 * dans ce dernier cas la liste des derniers numéros appelés est vide 
	 * alors rien ne se passe (le téléphone reste raccroché et le numéro 
	 * composé reste vide) sinon un message d'erreur est affiché : 
	 * 	"aucun numéro à appeler".
	 */
	public void decrocher(){
		if(numeroCompose != null){
			decroche = true;
			enCommunication = true;
			listeDerniersNumAppeles.addFirst(numeroCompose);
		}else if(!listeDerniersNumAppeles.isEmpty()){
			decroche = true;
			numeroCompose = listeDerniersNumAppeles.getFirst();
		}else{
			System.err.println("Aucun numero à appeler");
		}
	}
	
	/**
	 * Permet de raccrocher le téléphone ce qui interromp la 
	 * 	communication et remet le numéro composé à null. 
	 */
	public void raccrocher(){
		enCommunication = false;
		decroche = false;
		numeroCompose = null;
	}
	
	/**
	 * Permet d'ajouter un nouveau contact à la liste des contacts.
	 * @param nom Nom du contact à ajouter.
	 * @param prenom Prénom du contact à ajouter.
	 * @param numTel Numéro de téléphone du contact à ajouter.
	 * @throws Exception Exception si le nom ou le numéro de téléphone sont null, 
	 *   ou si le contact est déja présent dans la liste des contacts.
	 */
	public void ajouterNouveauContact(String nom, String prenom, String numTel)throws Exception{
		Contact c = new Contact(nom, prenom, numTel);
		if(listeContacts.contains(c)){
			throw new Exception("Ajout impossible : le contact est déjà présent dans le téléphone");
		}else{
			listeContacts.add(c);
		}
	}
	/**
	 * Permet d'ajouter un nouveau contact à la liste des contacts.
	 * @param nom Nom du contact à ajouter.
	 * @param numTel Numéro de téléphone du contact à ajouter.
	 * @throws Exception Exception si le nom ou le numéro de téléphone sont null, 
	 *   ou si le contact est déja présent dans la liste des contacts.
	 */
	public void ajouterNouveauContact(String nom, String numTel)throws Exception{
		ajouterNouveauContact(nom, null, numTel);
	}
	/**
	 * Permet de supprimer un contact de la liste des contacts.
	 * @param nom Nom du contact à supprimer.
	 * @param prenom Prénom du contact à supprimer.
	 * @return true si le contact était bien dans la liste des 
	 * 	contacts et donc a bien été supprimé.
	 */
	public boolean supprimerContact(String nom, String prenom){
		ListIterator<Contact> it = listeContacts.listIterator();
		Contact c = null;
		boolean trouve = false;
		while(it.hasNext()&& !trouve){
			c = it.next();
			if(c.getNom().equals(nom) && ((c.getPrenom()==null && prenom == null) || (prenom != null && prenom.equals(c.getPrenom())))){
				trouve = true;
			}
		}
		if(trouve){
			listeContacts.remove(c);
		}
		return trouve;
	}
	// autre façon :
	/*
	public boolean supprimerContact(String nom, String prenom){
		ListIterator<Contact> it = listeContacts.listIterator();
		Contact c = null;
		while(it.hasNext()){
			c = it.next();
			if(c.getNom().equals(nom) && ((c.getPrenom()==null && prenom == null) || (prenom != null && prenom.equals(c.getPrenom())))){
				it.remove();
				return true;
			}
		}
		return false;
	}
	*/

	/**
	 * Recherche dans la liste de contacts, le contact 
	 * 	correspondant au numéro de téléphone passé en paramètre. 
	 * 	
	 * @param numTel Numéro de téléphone du contact cherché.
	 * @return Retourne le contact cherché ou null si non trouvé.
	 */
	private Contact rechercherContact(String numTel){
		for(Contact c : listeContacts){
			if(c.getNumTel().equals(numTel)){
				return c;
			}
		}
		return null;
	}
	// autre façon : 
	/*
	private Contact rechercherContact(String numTel){
		ListIterator<Contact> it = listeContacts.listIterator();
		Contact c;
		while(it.hasNext()){
			c = it.next();
			if(c.getNumTel().equals(numTel)){
				return c;
			}
		}
		return null;
		
	}
	*/

	
	/**
	 * Affiche l'identité du contact correspondant au numéro de 
	 * 	téléphone passé en paramètre si celui-ci a été trouvé dans 
	 * 	la liste des contacts, ou alors affiche simplement le 
	 * 	numéro de téléphone si celui-ci ne correspond pas à un contact connu. 
	 * @param numTel Le numéro de téléphone dont on veut afficher 
	 * 	l'identité du contact correspondant si celui-ci est connu.
	 */
	public void afficherContact(String numTel){
		Contact c = rechercherContact(numTel);
		if(c!=null){
			System.out.println(c.getIdentite());
		}else{
			System.out.println(numTel);
		}
	}
	
	/**
	 * Recherche les contacts dont le nom commence par la lettre passée
	 * 	en paramètre.
	 * @param initialeNom L'initiale du nom des contact cherchés. 
	 * @return la liste des contacts connus et ayant pour initiale le lettre donnée.
	 */
	private LinkedList<Contact> rechercherContacts(char initialeNom){
		LinkedList<Contact> res = new LinkedList<Contact>();
		for(Contact c : listeContacts){
			if(c.getNom().charAt(0)== initialeNom){
				res.add(c);
			}
		}
		return res;	
	}
	// autre façon : 
	/*
	private LinkedList<Contact> rechercherContacts(char initialeNom){
		LinkedList<Contact> res = new LinkedList<Contact>();
		ListIterator<Contact> it = listeContacts.listIterator();
		Contact c;
		
		while(it.hasNext()){
			c = it.next();
			if(c.getNom().charAt(0)== initialeNom){
				res.add(c);
			}
		}
		return res;	
	}
	*/
	
	/**
	 * Affiche les contacts connus ayant pour initiale de leur 
	 * 	nom la lettre passée en paramètre.
	 * @param initialeNom Initiale du nom des contacts connus 
	 * 	que l'on souhaite afficher.
	 */
	public void afficherContacts(char initialeNom){
		LinkedList<Contact> lc = rechercherContacts(initialeNom);
		if(lc.size()==0){
			System.out.println("liste vide");
		}else{
			for(Contact c : lc){
				System.out.println(c);
			}
		}
	}
	// autre façon :
	/*
	public void afficherContacts(char initialeNom){
		LinkedList<Contact> lc = rechercherContacts(initialeNom);
		if(lc.size()==0){
			System.out.println("liste vide");
		}else{
			ListIterator<Contact> it = lc.listIterator();
			while(it.hasNext()){
				System.out.println(it.next());
			}
		}
	}
	*/ 

	
	/**
	 * Permet de voir (d'afficher) les derniers numéros appelés 
	 * 	par le téléphone.
	 */
	public void voirDerniersNumAppeles(){
		if(listeDerniersNumAppeles.size()==0){
			System.out.println("liste vide");
		}else{
			for(String num : listeDerniersNumAppeles){
				System.out.println(num);
			}
		}
	}
	// autre façon : 
	/*
	public void voirDerniersNumAppeles(){
		if(listeDerniersNumAppeles.size()==0){
			System.out.println("liste vide");
		}else{
			ListIterator<String> it = listeDerniersNumAppeles.listIterator();
			while(it.hasNext()){
				System.out.println(it.next());
			}
		}
	}
	*/
	
	/**
	 * Permet de vider la liste des derniers numéros appelés.
	 */
	public void viderDerniersNumAppeles(){
		listeDerniersNumAppeles.clear();
	}
	
	/**
	 * Permet de décrire l'état général du téléphone : 
	 * 	s'il est décrocjé, s'il est en communication 
	 * 	(et dans ce cas avec quel numéro ou quel contact connu), 
	 * 	ou s'il est raccroché. 
	 */
	public String toString(){
		String message;
		if(decroche){
			if(enCommunication){
				Contact c = rechercherContact(numeroCompose);
				if(c==null){
					message = "Telephone décroché et en communication avec le "
							+ numeroCompose + ".";
				}else{
					message = "Telephone décroché et en communication avec "
							+ c.getIdentite() + ".";
				}
				
			}else{
				message = "Telephone décroché.";
			}
		}else{
			message ="Telephone raccroché ";
		}
		return message;
	}
	
	
	
	
	
	
	
}
